from genericpath import isfile
import os
from patchify import patchify
from tqdm import tqdm
from PIL import Image as PILImage
import numpy as np
import enum 

class IMG_TYPE(enum.Enum):
    IMAGE = 0
    LABEL = 1

class Patchifier():
    # Data Location Properties
    img_src = None
    img_dst = None
    lbl_src = None
    lbl_dst = None
    lbl_suffix = None
    # Data Patchification Properties
    patch_X = None
    patch_Y = None
    step_size = None

    def __init__(self):
        self._is_src_defined = False
        self._is_dst_defined = False
        self._is_patch_defined = False
    def set_source_config(self,img_src:str,lbl_src:str,lbl_suffix:str="_gt"):
        """Define source directory for your Patchification

        Args:
            img_src (str): _description_
            lbl_src (str): _description_
            lbl_suffix (str): suffix on labels in order to give the same suffix to dst labels.

        Raises:
            OSError: _description_
            OSError: _description_
        """
        if not os.path.exists(img_src) or not os.path.isdir(img_src):
            raise OSError('{img_src} should be an existing folder')
        if not os.path.exists(lbl_src) or not os.path.isdir(lbl_src):
            raise OSError('{img_src} should be an existing folder')
        self.img_src = img_src
        self.lbl_src = lbl_src
        self.lbl_suffix = lbl_suffix
        self._is_src_defined = True

    def set_dest_config(self,img_dst:str,lbl_dst:str):
        """Define the destination directory for your Patchification

        Args:
            img_dst (str): _description_
            lbl_dst (str): _description_

        Raises:
            ValueError: _description_
        """
        os.makedirs(img_dst,exist_ok=True)
        ######################### Check
        for fname in os.listdir(img_dst):
            fpath = os.path.join(img_dst,fname)
            if os.path.isfile(fpath):
                raise ValueError('Image directory should be empty')
        os.makedirs(lbl_dst,exist_ok=True)
        for fname in os.listdir(lbl_dst):
            fpath = os.path.join(lbl_dst,fname)
            if os.path.isfile(fpath):
                raise ValueError('Label target directories should be empty')
        self.img_dst = img_dst
        self.lbl_dst = lbl_dst
        self._is_dst_defined = True
    
    def set_patch_config(self,patch_X:int,patch_Y:int,step_size:int):
        """Define the patch rules.

        Args:
            patch_X (int): _description_
            patch_Y (int): _description_
            padding_X (int): _description_
            padding_Y (int): _description_
        """
        self.patch_X = patch_X
        self.patch_Y = patch_Y
        self.step_size = step_size
        self._is_patch_defined = True

    def _patch_img(self,src_image_path:str,type:IMG_TYPE=IMG_TYPE.IMAGE):
        """Private method that will patch an image.

        Args:
            src_image_path (str): _description_
            type (IMG_TYPE, optional): _description_. Defaults to IMG_TYPE.IMAGE.
        """
        created = []
        if type == IMG_TYPE.IMAGE:
            dst_root_dir = self.img_dst
            img_name = os.path.basename(src_image_path)
            image_root = os.path.splitext(img_name)[0]
            image_ext = os.path.splitext(img_name)[1]
        elif type == IMG_TYPE.LABEL:
            dst_root_dir = self.lbl_dst
            img_name = os.path.basename(src_image_path)
            # On vire le suffix
            image_root = os.path.splitext(img_name)[0].replace(self.lbl_suffix,'')
            image_ext = f"{self.lbl_suffix}{os.path.splitext(img_name)[1]}"
        ######################################################
        with PILImage.open(src_image_path) as pil_img:
            mode = pil_img.mode
            img_array = np.array(pil_img)
        if len(img_array.shape) == 3:
            patch_size=(self.patch_X,self.patch_Y,img_array.shape[-1])
        else:
            patch_size=(self.patch_X,self.patch_Y)
        patches = patchify(img_array,patch_size=patch_size,step=self.step_size).squeeze()
        for row in range(patches.shape[0]):
            for col in range(patches.shape[1]):
                if type == IMG_TYPE.LABEL:
                    dst_img_path = os.path.join(dst_root_dir,image_root+f"_{row}{col}{image_ext}")
                elif type == IMG_TYPE.IMAGE:
                    dst_img_path = os.path.join(dst_root_dir,image_root+f"_{row}{col}{image_ext}")
                dst_pil_img=PILImage.fromarray(patches[row,col],mode=mode)
                dst_pil_img.save(dst_img_path)
                created.append(dst_img_path)
        return created

    def generate(self):
        """Generate new images in the new directory...

        Raises:
            ValueError: When not correctly initialized...
        """
        created = {}
        if not self._is_src_defined:
            raise ValueError('Define source directory with method set_source_config(..) ')
        if not self._is_dst_defined:
            raise ValueError('Define Destination directory with method set_dest_config(..) ')
        if not self._is_patch_defined:
            raise ValueError('Define source directory with method set_patch_config(..) ')
        # Images
        created['img']=[]
        for img_name in tqdm(os.listdir(self.img_src)):
            src_image_path = os.path.join(self.img_src,img_name)
            if os.path.isfile(src_image_path):
                created['img'].extend(self._patch_img(src_image_path,IMG_TYPE.IMAGE))
        # Labels
        created['label']=[]
        for img_name in tqdm(os.listdir(self.lbl_src)):
            src_image_path = os.path.join(self.lbl_src,img_name)
            if os.path.isfile(src_image_path):
                created['label'].extend(self._patch_img(src_image_path,IMG_TYPE.LABEL))
        return created




