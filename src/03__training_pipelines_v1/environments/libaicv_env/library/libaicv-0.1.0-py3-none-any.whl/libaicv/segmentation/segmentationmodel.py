import torch
import torch.nn as nn
from torch.optim import Adam
from torch.optim.lr_scheduler import StepLR

from ..core.figures.verdictsfigure import VFMODE
from ..core.factory import PPROCESS, OutputContext
from ..core.base import BaseModel
from ..core.losses import IoULoss,AggLoss
from ..core.losses import FocalCrossEntropyLoss as FCELoss
from ..core.metrics import IoUMetric
from ..core.figures import GradFlowFigure,VerdictFigure
from ..core.figures import ImageSemanticSegmentationFigure as ImageFigure

import copy
from typing import List

class SegmentationModel(BaseModel):
    name="SegmentationModel"
