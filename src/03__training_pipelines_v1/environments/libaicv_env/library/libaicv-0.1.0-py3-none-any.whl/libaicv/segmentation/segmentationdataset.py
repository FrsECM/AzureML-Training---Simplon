from ..core.base import BaseDataset,BaseImage
from ..core.factory import PPROCESS
from ..utils.os import Directory
from PIL import Image as PILImage
import os
import numpy as np
from typing import List
from yarrow import YarrowDataset
import cv2
from tqdm import tqdm
import torch

class SegmentationDataset(BaseDataset):
    clsNames = None
    def __init__(self,pprocess:PPROCESS,size:tuple=(128,128)):
        BaseDataset.__init__(self,pprocess,size)
        self.clsNames = []

    @property
    def clsCount(self):
        return len(self.clsNames)

    def __getitem__(self,idx):
        indice = idx%self.__len__()
        ImageInstance = self.data[indice]
        ImageInstance:BaseImage
        X = ImageInstance.get_data()
        y = ImageInstance.get_target(size=self.size,class_names = self.clsNames)
        if self.transform:
            output = self.transform(image=X,mask=y)
            X = output['image']
            y = output['mask']
        X:torch.Tensor
        y:torch.Tensor
        return X.float(),y.long(),ImageInstance.name

    def fromFolder(
        data_directory:str,
        label_directory:str,
        clsNames:List[str],
        label_suffix:str="_gt.png",
        pprocess=PPROCESS.NORMALIZE,
        size:tuple=(128,128),
        nmax:int=None) -> BaseDataset:
        """Create a Segmentation Dataset from a folder of data...

        Args:
            data_directory (str): Directory containing images
            label_directory (str): Directory containing label as images.
            class_names (List[str]): Class Names
            label_suffix (str, optional): _description_. Defaults to "_gt.png".
            pprocess (_type_, optional): _description_. Defaults to pprocess.STANDARDIZE.
            size (tuple, optional): _description_. Defaults to (128,128).
            nmax(int,opptional): Max samples to keep, Default None
        Raises:
            TypeError: _description_

        Returns:
            _type_: _description_
        """
        if not isinstance(size,tuple) or len(size)!=2:
            raise TypeError("Size should be a tuple (SizeX,SizeY)")
        if not isinstance(clsNames,list):
            raise TypeError("Class names should be a list")
        # We setup our dataset instance...
        dataset = SegmentationDataset(pprocess,size)
        dataset.clsNames = list(clsNames)
        img_dir = Directory(data_directory)
        lbl_dir = Directory(label_directory)
        # We get files from directory
        img_roots = img_dir.get_fileroots()
        img_paths = img_dir.get_filepaths()
        for i,(root,path) in tqdm(enumerate(zip(img_roots,img_paths)),total=len(img_roots)):
            if nmax is None or i<nmax:
                if lbl_dir.exists(f"{root}{label_suffix}"):
                    ImageInstance = SegmentationFolderImage(path,os.path.join(label_directory,f"{root}{label_suffix}"))
                    dataset.data.append(ImageInstance)
            else:
                return dataset
        return dataset

    def fromYarrows(
        data_root_dir:str,
        yarrow_root_dir:str,
        yarrow_ext:str=".yarrow.json",
        pprocess=PPROCESS.NORMALIZE,
        size:tuple=(128,128),
        nmax:int=None):

        dataset = SegmentationDataset(pprocess,size)
        yar_paths=[]
        for root,_,files in os.walk(yarrow_root_dir):
            yar_paths.extend([os.path.join(root,yr) for yr in files if yr.endswith(yarrow_ext)])
        yar_paths.sort()
        if nmax:
            yar_paths=yar_paths[:nmax]
        dataset.clsNames=['Background'] # We create background class
        for yr_path in tqdm(yar_paths):
            Annotation=SegmentationYarrowImage(data_root_dir,yr_path)
            # We add the class in class_names
            for cls in Annotation.class_names:
                if cls not in dataset.clsNames:
                    dataset.clsNames.append(cls)
            dataset.data.append(Annotation)
        return dataset


class SegmentationFolderImage(BaseImage):
    def __init__(self,img_path:str,lbl_path:str):
        if not os.path.exists(img_path):
             raise OSError(f"Image Path do not exists \n{img_path}")
        if not os.path.exists(lbl_path):
             raise OSError(f"Label Path do not exists \n{img_path}")
        # We get the name from image name.
        self.name = os.path.splitext(os.path.basename(img_path))[0]
        self.img_path = img_path
        self.lbl_path = lbl_path
    def get_target(self,**kwargs):
        with PILImage.open(self.lbl_path) as pil_img:
            np_array = np.array(pil_img).astype(np.uint8)
        return np_array

class SegmentationYarrowImage(BaseImage):
    def __init__(self,data_root_dir:str,yarrow_path:str):
        if not os.path.exists(data_root_dir):
             raise OSError(f"DataRootDir do not exists \n{data_root_dir}")
        if not os.path.exists(yarrow_path):
             raise OSError(f"Yarrow Path do not exists \n{yarrow_path}")
        # We get the name from image name.
        self.name = os.path.splitext(os.path.basename(yarrow_path))[0]
        self.data_root_dir = data_root_dir
        self.lbl_path = yarrow_path
        self.yar_obj = YarrowDataset.parse_file(self.lbl_path)
        if len(self.yar_obj.images)==0:
            raise ValueError("Yarrow should contains at least one image...")
        # Get height / width
        self.width = self.yar_obj.images[0].width
        self.height = self.yar_obj.images[0].height
        self.class_names = list(set([annotation.name for annotation in self.yar_obj.annotations]))
    def get_data(self):
        """Get stacked data from yarrow file...

        Returns:
            _type_: _description_
        """
        im_list=[]
        for im in self.yar_obj.images:
            impath=os.path.join(self.data_root_dir,im.file_name)
            with PILImage.open(impath) as s_pil:
                img=np.array(s_pil).astype(np.uint8)
                if len(img.shape)==2:
                    im_list.append(img[:,:,np.newaxis])
                else:
                    im_list.append(img)
        return np.concatenate(im_list,axis=-1)
    def get_target(self,class_names:list=None,size:tuple=None):
        """Get the target from the yarrow file...

        Args:
            class_names (list, optional): _description_. Defaults to None.
            size (tuple, optional): _description_. Defaults to None.

        Returns:
            _type_: _description_
        """
        if size is not None:
            height = size[0]
            width = size[1]
        target_result=np.zeros((height or self.height,width or self.width))
        for annotation in self.yar_obj.annotations:
            if annotation.polygon is not None:
                if class_names is not None:
                    if annotation.name not in class_names:
                        raise ValueError(f"Annotation {annotation.name} not in class_names {class_names}")
                    cls_id = class_names.index(annotation.name)
                else:
                    cls_id = 1
                p=np.asarray(annotation.polygon)*target_result.shape[::-1] # On multiplie par la taille de la target pour avoir de l'absolu
                cv2.fillPoly(target_result,np.int32([p]),cls_id)
        return target_result