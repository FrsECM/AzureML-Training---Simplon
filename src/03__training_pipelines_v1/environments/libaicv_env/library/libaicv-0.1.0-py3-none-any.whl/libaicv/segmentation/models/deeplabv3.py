import torch.nn as nn
from torchvision.models.segmentation import deeplabv3_resnet50,DeepLabV3_ResNet50_Weights
from .. import SegmentationModel
from ...core.factory import PPROCESS
import copy
from typing import List

class DeepLabv3(SegmentationModel):
    name="DeepLabv3"
    def __init__(self, nChannels: int, clsCount: int, 
        activation=nn.ReLU(),
        pretrained:bool=True):
        """_summary_

        Args:
            nChannels (int): _description_
            clsCount (int): _description_

        """
        super().__init__()
        parameters = DeepLabV3_ResNet50_Weights.DEFAULT if pretrained else None
        model=deeplabv3_resnet50(parameters=parameters)
        # On va gérer le cas du modèle prétrained...
        if pretrained:
            weights_conv1=copy.deepcopy(model.backbone.conv1.weight.data[:,1,:,:])
            model.backbone.conv1 = nn.Conv2d(nChannels, 64, kernel_size=(7,7), stride=(2,2), padding=(3,3),bias=False)
            for i in range(nChannels):
                # On recopie le channels vert d'imagenet dans l'ensemble des channels.
                model.backbone.conv1.weight.data[:,i,:,:]=weights_conv1
        else:
            model.backbone.conv1 = nn.Conv2d(nChannels, 64, kernel_size=7, stride=2, padding=3,bias=False)
        self.model=model
        self.model.classifier[-1]=nn.Conv2d(256,clsCount,1,1,0)
        self.activation=activation
        # We set optionnal parameters

    def forward(self,x):
        y=self.model(x)['out'] # On récupère la méthode out.
        y=self.activation(y)
        return y