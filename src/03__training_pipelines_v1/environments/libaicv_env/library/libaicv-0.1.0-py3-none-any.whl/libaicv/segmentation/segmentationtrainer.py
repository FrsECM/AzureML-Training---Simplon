from ..core.factory import TRAINER_EVENTS,IBaseModel,OutputContext
from ..core.base import BaseTrainer
from ..core.callbacks import LoggerCallback,CheckpointCallback
from ..core.losses import IoULoss,AggLoss
from ..core.losses import FocalCrossEntropyLoss as FCELoss
from ..core.metrics import IoUMetric
from ..core.figures import GradFlowFigure,VerdictFigure
from ..core.figures import ImageSemanticSegmentationFigure as ImageFigure
from ..core.figures.verdictsfigure import VFMODE
from .import SegmentationDataset,SegmentationModel
import torch

class SegmentationTrainer(BaseTrainer):
    Lr0 = 1e-5
    num_worker = 0
    nThresholds:int=25
    gradflow_frequency:int=100
    imagefig_frequency_train:int=50
    imagefig_frequency_val:int=50
    alpha_fce:float = 0.5
    display_dim:int = 0

    def __init__(self,model:IBaseModel,root_logdir='tb_logdir',log_batch:bool=True,**kwargs):
        super().__init__(model,**kwargs)
        self.tb_callback = LoggerCallback(self,rootLogDir=root_logdir,LogDir_suffix=model.name)
        # We attach tensorboard Callback to events...
        ########################################################################################
        #  BATCH END Events
        ########################################################################################
        if log_batch:
            # If we activate logbatch, we'll log every loss every batch
            self.tb_callback.attach_event(TRAINER_EVENTS.ON_TRAIN_BATCH_END,"TrainLoss")
            self.tb_callback.attach_event(TRAINER_EVENTS.ON_VAL_BATCH_END,"ValLoss")
            self.tb_callback.attach_event(TRAINER_EVENTS.ON_VAL_BATCH_END,"ValMetrics")
        # Anyway, we plot figures that have a batch frequency...
        self.tb_callback.attach_event(TRAINER_EVENTS.ON_TRAIN_BATCH_END,"TrainFigures")
        self.tb_callback.attach_event(TRAINER_EVENTS.ON_VAL_BATCH_END,"ValFigures")
        ########################################################################################
        #  LOOP END Events
        ########################################################################################
        self.tb_callback.attach_event(TRAINER_EVENTS.ON_TRAIN_LOOP_END,"TrainLoss")
        self.tb_callback.attach_event(TRAINER_EVENTS.ON_VAL_LOOP_END,"ValLoss")
        self.tb_callback.attach_event(TRAINER_EVENTS.ON_VAL_LOOP_END,"ValFigures")
        self.tb_callback.attach_event(TRAINER_EVENTS.ON_VAL_LOOP_END,"ValMetrics")
        # We create Checkpoints
        self.cp_callback = CheckpointCallback(self,self.tb_callback.logdir,"TotalLoss",method='min')
        self.cp_callback.attach_event(TRAINER_EVENTS.ON_VAL_LOOP_END,"ValLoss")
        self.set_kwargs(kwargs)

    def check(self):
        super().check()
        assert isinstance(self.current_dataset,SegmentationDataset)
        assert isinstance(self.model,SegmentationModel)

    @torch.enable_grad()
    def train_step(self,batch, device = 'cpu')->dict:
        self.current_dataset:SegmentationDataset
        self._optimizer.zero_grad()
        X,y,_ = batch
        X = X.to(device).float()
        y = y.to(device)
        nBatch = X.shape[0]
        with torch.cuda.amp.autocast(enabled=self._isAMP):
            pred = self.model.forward(X)
            with OutputContext(context="TrainLoss"):
                # We compute Losses
                fce_loss = FCELoss('FocalCELoss').forward(pred,y.long())
                iou_loss = IoULoss(name='IoULoss').forward(pred,y.long())
                total_loss = AggLoss(name='TotalLoss').forward(self.alpha_fce*fce_loss+(1-self.alpha_fce)*iou_loss)
                self.backward_step(total_loss)
            # We compute Frequencials
            with OutputContext(context="TrainFigures"):
                GradFlowFigure("Gradient",freq=self.gradflow_frequency).update(self.model)
                ImageFigure("ImageSegmentation",freq=self.imagefig_frequency_train,pprocess=self.current_dataset.pprocess,display_dim=self.display_dim).update(X,y,pred)
            # We return trainingOutputs containing "stackers"...
        return {'ce_loss':fce_loss.item(),'iou_loss':iou_loss.item(),'total_loss':total_loss.item()}
        
    @torch.no_grad()
    def val_step(self,batch,device = 'cpu')->dict:
        self.current_dataset:SegmentationDataset
        X,y,_ = batch
        nBatch=X.shape[0]
        X=X.to(device)
        y=y.to(device)
        with torch.cuda.amp.autocast(enabled=self._isAMP):
            pred=self.model.forward(X)
            # We compute Losses
            with OutputContext(context="ValLoss"):
                fce_loss = FCELoss('FocalCELoss').forward(pred,y.long())
                iou_loss = IoULoss(name='IoULoss').forward(pred,y.long())
                total_loss = AggLoss(name='TotalLoss').forward(self.alpha_fce*fce_loss+(1-self.alpha_fce)*iou_loss)
                # First, we need to compute softmax on prediction...
                pred_softmaxed=torch.softmax(pred,dim=1) # We softmax on the first dim and put it in the end for further masking
            with OutputContext(context="ValFigures"):
                #############################################################
                #### We compute Metrics
                #############################################################
                # We plots images...
                ImageFigure("ImageSegmentation",freq=self.imagefig_frequency_val,pprocess=self.current_dataset.pprocess,display_dim=self.display_dim).update(X,y,pred_softmaxed,apply_softmax=False)
                VerdictFigure("Verdicts",clsIDs=range(1,self.current_dataset.clsCount),clsNames=self.current_dataset.clsNames,modes=[VFMODE.PRCURVE,VFMODE.VIDICURVE]).update(pred_softmaxed,y,apply_softmax=False)
            with OutputContext(context="ValMetrics"):
                for i in range(1,self.current_dataset.clsCount):
                    pred_cls = pred_softmaxed[:,i,:,:]>0.5
                    target_cls = y==i
                    cls_name = self.current_dataset.clsNames[i]
                    IoUMetric(f'IoUMetric_{cls_name}_0.5').update(pred_cls,target_cls)
        return {'ce_loss':fce_loss.item(),'iou_loss':iou_loss.item(),'total_loss':total_loss.item()}
    
    def test_step(self,batch,device = 'cpu')->dict:
        return NotImplemented