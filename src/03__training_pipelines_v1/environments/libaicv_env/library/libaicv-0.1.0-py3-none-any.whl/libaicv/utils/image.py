from ..core.factory import PPROCESS
import numpy as np
import torch
from typing import Union

def overlay(image:Union[np.ndarray,torch.Tensor],mask:Union[np.ndarray,torch.Tensor],alpha = 0.4):
    assert len(image.shape) in [2,3],"Image shape should be [H,W,C] or [H,W]"
    assert len(mask.shape) in [2,3],"Mask shape should be [H,W,C] or [H,W]"
    assert image.shape[:2] == mask.shape[:2],"Image and Mask should be the same shape"
    if isinstance(image,torch.Tensor):
        image = image.numpy()
    if isinstance(mask,torch.Tensor):
        mask = mask.numpy()
    if len(image.shape)==2:
        img_RGB = np.expand_dims(image,axis=-1)
        img_RGB = img_RGB.repeat(3,axis = -1)
    else:
        img_RGB=image
    if len(mask.shape)==2:
        msk_RGB = np.expand_dims(mask,axis=-1)
        msk_RGB = msk_RGB.repeat(3,axis = -1)
    else:
        msk_RGB=mask
    res = img_RGB * (1-alpha) + msk_RGB * alpha
    return res.astype(np.uint8)
        
def colorize_classification(
        X:np.ndarray,
        y_cls:int,p_cls:int,
        bg_class:int = 0,
        border:int=3):
    if not isinstance(X,np.ndarray) and not isinstance(X,torch.Tensor):
        raise TypeError('X should be a torchTensor or a Numpy Array')
    if len(X.shape) not in [2,3]:
        raise ValueError('X should be [H,W],[H,W,1] or [H,W,3]')
    if isinstance(X,torch.Tensor):
        X = X.numpy()
    # We manage images without RGB
    if len(X.shape) == 2:
        # We need to add a 3rd dimension
        X = np.expand_dims(X,-1)
    if X.shape[-1] == 1:
        # We add RGB channels
        X = np.repeat(X,3,axis=-1)
    assert len(X.shape) == 3,"X should be [H,W,3]"
    assert X.shape[2] == 3,"X should be [H,W,3]"
    X_plot = X.copy()
    colors = {
        'orange':np.array([255,191,0]), # Tipically for False Detections
        'green1':np.array([0,255,0]), # Typically for Well classifyed Images
        'green2':np.array([0,196,0]), # Typically for Well classifyed Images
        'red':np.array([255,0,0]), # Tipically for Leaks
    }
    # We now define the color...
    if y_cls == bg_class and y_cls == p_cls:
        color = colors['green1']
    elif y_cls == bg_class and y_cls != p_cls:
        color = colors['orange']
    elif y_cls != bg_class and y_cls == p_cls:
        color = colors['green2']
    elif y_cls != bg_class and p_cls == bg_class:
        color = colors['red']
    else:
        color = colors['orange']
    # We'll create borders
    X_plot[0:border,:] = color
    X_plot[-border:,:] = color
    X_plot[:,0:border] = color
    X_plot[:,-border:] = color
    return X_plot

def colorize_segmentation(ClassMat:Union[np.ndarray,torch.Tensor]):
    """
    Args:
        ClassMat (_type_): array [H,W]
    Returns:
        _type_: _description_
    """
    if not isinstance(ClassMat,np.ndarray) and not isinstance(ClassMat,torch.Tensor):
        raise TypeError('ClassMat should be a torchTensor or a Numpy Array')
    if len(ClassMat.shape)!=2:
        raise ValueError("ClassMat should be a [H,W] array")
    colors=[
        np.array([0,0,0]), # Noir
        np.array([255,0,0]), # Rouge
        np.array([255,165,0]), # Orange
        np.array([0,0,255]), # Bleu
        np.array([0,255,0]), # Vert
        np.array([128,0,0]), # Rouge foncé
        np.array([0,0,128]), # Bleu foncé
        np.array([0,128,0]), # Vert foncé
    ]
    if isinstance(ClassMat,torch.Tensor):
        ClassMat = ClassMat.numpy()
    H,W=ClassMat.shape[0],ClassMat.shape[1]
    result=np.zeros((H,W,3))
    # We get Unique values...
    values = list(np.unique(ClassMat).astype(np.uint8))
    values.sort()
    for i,value in enumerate(values):
        # Dans le cas ou on a pas assez de couleurs...
        idc=value%len(colors)
        result[ClassMat==value]=colors[idc]
    return result.astype(np.uint8)

def transform(X:np.ndarray,norm:PPROCESS=PPROCESS.STANDARDIZE,**kwargs)->np.ndarray:
    """Transform an array to be processed by Pipeline.

    Args:
        X (np.ndarray): _description_
        norm (NORM, optional): _description_. Defaults to NORM.STANDARDIZE.

    Raises:
        TypeError: _description_
        TypeError: _description_
        NotImplementedError: _description_

    Returns:
        _type_: _description_
    """
    if not isinstance(norm,PPROCESS):
        raise TypeError('norm argument should be a NORM')
    if not isinstance(X,np.ndarray):
        raise TypeError('X argument should be a np.ndarray')
    if len(X.shape) not in [2,3]:
        raise TypeError(f'X must be [HWC,CHW,HW], {len(X.shape)} given')
    if norm == PPROCESS.STANDARDIZE:
        return X/255
    elif norm == PPROCESS.NORMALIZE:
        return (X/255)*2-1
    else:
        raise NotImplementedError()
    
def reverse(X:torch.Tensor,norm:PPROCESS=PPROCESS.STANDARDIZE,**kwargs)-> np.ndarray:
    """_summary_

    Args:
        X (torch.Tensor): [B,C,H,W]
        norm (NORM, optional): _description_. Defaults to NORM.STANDARDIZE.

    Raises:
        TypeError: _description_
        TypeError: _description_
        TypeError: _description_
        NotImplementedError: _description_

    Returns:
        np.ndarray: _description_
    """
    if not isinstance(norm,PPROCESS):
        raise TypeError('norm argument should be a NORM')
    if not isinstance(X,torch.Tensor):
        raise TypeError('X argument should be a torch.Tensor')
    if len(X.shape)!=4:
        raise TypeError('X should be [B,C,H,W] (usually C = 1 or 3)')
    if norm == PPROCESS.STANDARDIZE:
        result_torch =X.detach().cpu().permute(0,2,3,1)*255
        return result_torch.numpy().astype(np.uint8)
    if norm == PPROCESS.NORMALIZE:
        result_torch = 255*((X.detach().cpu().permute(0,2,3,1)+1)/2)
        return result_torch.numpy().astype(np.uint8)
    else:
        raise NotImplementedError()