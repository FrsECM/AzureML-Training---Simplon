import cv2
import numpy as np


def Mask_to_Polygons(image,min_surface:int=100,MaxError:int=1):
    """Returns a list of polygon from mask detection

    Args:
        image (_type_): bool map
        classes (_type_): _description_
        min_surface (int, optional): _description_. Defaults to 100.

    Returns:
        _type_: _description_
    """
    detections = []
    contours, _ = cv2.findContours((image==1).astype(np.uint8), cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
    for object in [c for c in contours if cv2.contourArea(c)>min_surface]:
        coords = []
        for point in object:
            coords.append(int(point[0][0]))
            coords.append(int(point[0][1]))
        detections.append(np.array(coords).reshape(-1,2))
    simplified_detections=[cv2.approxPolyDP(poly, MaxError,closed=True).squeeze() for poly in detections]
    return simplified_detections