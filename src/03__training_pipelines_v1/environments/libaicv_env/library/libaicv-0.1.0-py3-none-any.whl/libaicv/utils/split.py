import numpy as np

def split(indices,train_ratio:int=0.8,val_ratio:int=0.1,test_ratio:int=0.1):
    """
    Generate a split from indices in a list.

    Args:
        indices (_type_): _description_
        train_ratio (int, optional): _description_. Defaults to 0.8.
        val_ratio (int, optional): _description_. Defaults to 0.1.
        test_ratio (int, optional): _description_. Defaults to 0.1.
        seed (int, optional): _description_. Defaults to 42.
    """
    if train_ratio+val_ratio+test_ratio != 1:            
        total_ratio = (train_ratio+val_ratio+test_ratio)
        train_ratio = train_ratio/total_ratio
        val_ratio = val_ratio/total_ratio
        test_ratio = test_ratio/total_ratio
    np.random.shuffle(indices)
    n_train = int(len(indices)*train_ratio)
    n_val = int(len(indices)*val_ratio)
    train_indices = indices[:n_train]
    val_indices = indices[n_train:n_train+n_val]
    test_indices = indices[n_train+n_val:]
    return train_indices,val_indices,test_indices