import torch

class GPU_Utils:
    def unload(input):
        if isinstance(input,torch.Tensor):
            if input.nelement()==1:
                return input.item()
            else:
                return input.detach().cpu()
        if isinstance(input,dict):
            return {k:GPU_Utils.unload(v) for (k,v) in input.items()}
        else:
            return input
    
    def get_memory_free_MiB(device):
        return torch.cuda.mem_get_info(device)