import torch
import torch.nn as nn
from torch.optim import Adam
from torch.optim.lr_scheduler import StepLR

from ..core.figures.verdictsfigure import VFMODE
from ..core.factory import PPROCESS, OutputContext
from ..core.base import BaseModel
from ..core.losses import CrossEntropyLoss
from ..core.figures import GradFlowFigure,VerdictFigure,ConfusionMatrixFigure
from ..core.figures import ImageClassificationFigure as ImageFigure

import copy
from typing import List

class ClassificationModel(BaseModel):
    name="ClassificationModel"
