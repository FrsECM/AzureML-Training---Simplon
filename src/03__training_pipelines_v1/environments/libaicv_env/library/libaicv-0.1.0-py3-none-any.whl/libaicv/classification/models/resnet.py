import torch.nn as nn
import torch
from torchvision.models import resnet18,resnet34,resnet50
from torchvision.models import ResNet18_Weights,ResNet34_Weights,ResNet50_Weights

from ..classificationmodel import ClassificationModel
from ...core.factory import PPROCESS
from typing import List


global MODELS
MODELS={
    "resnet18":{'model':resnet18,'weights':ResNet18_Weights.DEFAULT,'features':512},
    "resnet34":{'model':resnet34,'weights':ResNet34_Weights.DEFAULT,'features':512},
    "resnet50":{'model':resnet50,'weights':ResNet50_Weights.DEFAULT,'features':2048},
}

class ResNetClassifier(ClassificationModel):
    """ ResNetEncoder :
        Cette classe permet de créer un encodeur et de mettre à disposition les shortcuts
        si jamais on veut y coupler un décodeur.
        C'est utile pour des architecture de type :
        - Unet
        - Encoder / Décodeur
        - HeatMap + Embeding.

    Args:
        nn ([type]): [description]
    """
    def __init__(self, 
            nChannels: int, 
            clsCount: int, 
            backbone:str ='resnet18',
            pretrained:bool = True,
            **kwargs):
        super().__init__()
        assert backbone in MODELS.keys(),f"backbone {backbone} should be in {list(MODELS.keys())}"
        model_config = MODELS[backbone]
        # We get parameters
        weights = model_config['weights'] if pretrained else None
        model=model_config['model'](weights=weights) # Pas besoin de préentrainer car on tue le premier layer...
        model.conv1 = nn.Conv2d(nChannels, 64, kernel_size=7, stride=2, padding=3,bias=False)
        model.fc = nn.Linear(model_config['features'],out_features=clsCount)
        self.model = model

    def forward(self,x):
        y = self.model(x)
        return y
