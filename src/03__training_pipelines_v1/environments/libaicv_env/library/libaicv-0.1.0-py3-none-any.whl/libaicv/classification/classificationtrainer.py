from torch.optim import Adam
import torch

from ..core.factory import TRAINER_EVENTS,IBaseModel
from ..core.base import BaseTrainer
from ..core.callbacks import LoggerCallback,CheckpointCallback
from ..core.figures.verdictsfigure import VFMODE
from ..core.factory import PPROCESS, OutputContext
from ..core.base import BaseModel
from ..core.losses import CrossEntropyLoss
from ..core.figures import GradFlowFigure,VerdictFigure,ConfusionMatrixFigure
from ..core.figures import ImageClassificationFigure as ImageFigure
from .import ClassificationDataset,ClassificationModel

class ClassificationTrainer(BaseTrainer):
    Lr0:float = 1e-4
    nThresholds:int=25
    gradflow_frequency:int=100
    imagefig_frequency_train:int=50
    imagefig_frequency_val:int=50
    imagefig_border:int = 3

    def __init__(self,model:IBaseModel,root_logdir='tb_logdir',num_worker:int=0,log_batch:bool=True,**kwargs):
        super().__init__(model)
        self.num_worker=num_worker
        self.tb_callback = LoggerCallback(self,rootLogDir=root_logdir,LogDir_suffix=model.name)
        # We attach tensorboard Callback to events...
        ########################################################################################
        #  BATCH END Events
        ########################################################################################
        if log_batch:
            # If we activate logbatch, we'll log every loss every batch
            self.tb_callback.attach_event(TRAINER_EVENTS.ON_TRAIN_BATCH_END,"TrainLoss")
            self.tb_callback.attach_event(TRAINER_EVENTS.ON_VAL_BATCH_END,"ValLoss")
        # Anyway, we plot figures that have a batch frequency...
        self.tb_callback.attach_event(TRAINER_EVENTS.ON_TRAIN_BATCH_END,"TrainFigures")
        self.tb_callback.attach_event(TRAINER_EVENTS.ON_VAL_BATCH_END,"ValFigures")
        ########################################################################################
        #  LOOP END Events
        ########################################################################################
        self.tb_callback.attach_event(TRAINER_EVENTS.ON_TRAIN_LOOP_END,"TrainLoss")
        self.tb_callback.attach_event(TRAINER_EVENTS.ON_VAL_LOOP_END,"ValLoss")
        self.tb_callback.attach_event(TRAINER_EVENTS.ON_VAL_LOOP_END,"ValFigures")
        # We create Checkpoints
        self.cp_callback = CheckpointCallback(self,self.tb_callback.logdir,"CELoss",method='min')
        self.cp_callback.attach_event(TRAINER_EVENTS.ON_VAL_LOOP_END,"ValLoss")
        self.set_kwargs(kwargs)
        
    def check(self):
        super().check()
        assert isinstance(self.current_dataset,ClassificationDataset)
        assert isinstance(self.model,ClassificationModel)
        
    @torch.enable_grad()
    def train_step(self,batch, device = 'cpu')->dict:
        self._optimizer.zero_grad()
        X,y,_ = batch
        X = X.to(device).float()
        y = y.to(device)
        nBatch = X.shape[0]
        pred = self.model.forward(X)
        with torch.cuda.amp.autocast(enabled=self._isAMP):
            with OutputContext(context="TrainLoss"):
                # We compute Losses
                ce_loss = CrossEntropyLoss('CELoss').forward(pred,y.long())
                self.backward_step(ce_loss)
            with OutputContext(context="TrainFigures"):
                # We compute Frequencials
                GradFlowFigure("Gradient",freq=self.gradflow_frequency).update(self.model)
                ImageFigure("ImageCls",freq=self.imagefig_frequency_train,pprocess=self.current_dataset.pprocess,clsNames=self.current_dataset.clsNames,border=self.imagefig_border).update(X,y,pred)
                # We return trainingOutputs containing "stackers"...
        return {'ce_loss':ce_loss.item()}
        
    @torch.no_grad()
    def val_step(self,batch,device = 'cpu')->dict:
        self.current_dataset:ClassificationDataset
        X,y,_ = batch
        nBatch=X.shape[0]
        X=X.to(device)
        y=y.to(device)
        with torch.cuda.amp.autocast(enabled=self._isAMP):
            pred=self.model.forward(X)
            # We compute Losses
            with OutputContext(context="ValLoss"):
                ce_loss = CrossEntropyLoss('CELoss').forward(pred,y.long())
                # First, we need to compute softmax on prediction...
                pred_softmaxed=torch.softmax(pred,dim=1) # We softmax on the first dim and put it in the end for further masking
            with OutputContext(context="ValFigures"):
                #############################################################
                #### We compute Metrics
                #############################################################
                # We plots images...
                ImageFigure("ImageCls",freq=self.imagefig_frequency_val,pprocess=self.current_dataset.pprocess,clsNames=self.current_dataset.clsNames,border=self.imagefig_border).update(X,y,pred_softmaxed,apply_softmax=False)
                VerdictFigure("Verdicts",clsIDs=range(self.current_dataset.clsCount),clsNames=self.current_dataset.clsNames,modes=[VFMODE.PRCURVE,VFMODE.VIDICURVE]).update(pred_softmaxed,y,apply_softmax=False)
                ConfusionMatrixFigure("ConfMatrix",clsIDs=range(self.current_dataset.clsCount),clsNames=self.current_dataset.clsNames).update(pred_softmaxed,y,apply_softmax=False)
        return {'ce_loss':ce_loss.item()}
    
    def test_step(self,batch,device = 'cpu')->dict:
        return NotImplemented