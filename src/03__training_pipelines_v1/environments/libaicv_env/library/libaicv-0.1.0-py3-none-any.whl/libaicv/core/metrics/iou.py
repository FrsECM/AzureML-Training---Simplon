from ..factory import OUTPUT_TYPE
from ...core.base import BaseMetric
import torch
from typing import List

def IoU_metric(prediction:torch.Tensor,target:torch.Tensor,classe:int=1):
    """Compute the Intersection over Union for all non 0 classes.
    Args:
        prediction (torch.Tensor): prediction tensor [nBatch,H,W]
        target (torch.Tensor): target tensor [nBatch,H,W]
        classe (int, optional): _description_. Defaults to 1
    Returns:
        Intersection,Union
    """
    assert len(prediction.shape)==3,f"prediction shape {prediction.shape} should be [nBatch,H,W]"
    assert prediction.shape==target.shape,f"prediction shape {prediction.shape} should be = target shape {target.shape}"
    Intersection=torch.logical_and(prediction==classe,target==classe).sum()
    Union=torch.logical_or(prediction==classe,target==classe).sum()
    return Intersection,Union

def GetIoUMat(prediction_softmaxed:torch.Tensor,target:torch.Tensor,classes:List[str],reduction = None)-> torch.Tensor:
    """Compute the IoU matrix
    Args:
        prediction_softmaxed (torch.Tensor): prediction softmaxed [B,nClasses,H,W]
        target (torch.Tensor): target [B,H,W], each value is the cls_id
        classes (list[str]): list of classes ['Background','Class1',...]
    Returns:
        results (torch.Tensor): Tensor of shape [1,nClasses,2] (2 = Intersection,Union)
    """
    assert len(prediction_softmaxed.shape)==4,f"Prediction Softmaxed should be [B,nClasses,H,W] {prediction_softmaxed.shape} given"
    assert len(target.shape)==3,f"target should be [B,H,W] {target.shape} given"
    nBatch=target.shape[0]
    result=torch.zeros((nBatch,len(classes),2))
    for ibatch in range(nBatch):
        MaxMap=prediction_softmaxed[ibatch,:,:,:].max(dim=0)[1].unsqueeze(0) # On récupère la classMaxMap
        targetBatch=target[ibatch].unsqueeze(0)
        for iclasse in range(len(classes)):
            Intersection,Union=IoU_metric(MaxMap,targetBatch,iclasse)
            result[ibatch,iclasse,:]=torch.Tensor([Intersection,Union])
    if reduction == 'mean':
        return result.mean(dim = 0).unsqueeze(0) # On moyenne sur la première dim
    return result

class IoUMetric(BaseMetric):
    def __init__(self,name:str):
        BaseMetric.__init__(self,name)
        self._intersection = []
        self._union = []

    def reset(self):
        self._intersection=[]
        self._union = []

    def update(self, pred:torch.tensor,target:torch.tensor,classe:int=1):
        intersection,union = IoU_metric(pred,target,classe)
        self._intersection.append(intersection)
        self._union.append(union)
        return intersection,union
    
    def get(self):
        if len(self._intersection)>0 and len(self._union)>0:
            return (self._intersection[-1]+1e-5)/(self._union[-1]+1e-5)
    
    def agg(self):
        return torch.sum(torch.tensor(self._intersection)+1e-5,dtype=torch.float)/torch.sum(torch.tensor(self._union)+1e-5,dtype=torch.float)

    def __call__(self,pred:torch.tensor,target:torch.tensor,classe:int=1):
        """_summary_

        Args:
            pred (torch.tensor): [B,H,W]
            target (torch.tensor): [B,H,W]
            classe (int, optional):  Defaults to 1.

        Returns:
            _type_: _description_
        """
        intersection,union = self.update(pred,target,classe)
        return intersection,union


