import torch.nn as nn
import torch
from ..base import BaseLoss

class L2Loss(BaseLoss):
    def __init__(self,name:str="L2Loss"):
        super().__init__(name,stack_method=torch.mean)
    def forward(self,Noise,Pred):
        """Returns the L2 loss

        Args:
            Noise (_type_): _description_
            Pred (_type_): _description_

        Returns:
            _type_: _description_
        """
        batch_size=Noise.shape[0]
        norm_l2 = torch.norm(Noise.view(batch_size,-1) - Pred.view(batch_size,-1),p=2,dim=-1)
        loss_val = torch.mean(norm_l2)
        self.update(loss_val)
        return loss_val