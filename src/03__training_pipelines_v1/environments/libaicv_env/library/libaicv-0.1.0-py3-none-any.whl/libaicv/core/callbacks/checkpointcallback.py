from . import BaseCallback
from ..factory import IBaseTrainer,TRAINER_EVENTS, ICollectable,OutputContext
import os
import torch


COMPARE_METHOD = {
    'min':min,
    'max':max
}

class CheckpointCallback(BaseCallback):
    """
    The aim of this callback is to log metrics in tensorboard.
    There is two modes :
    - Batchs
    - Loops
    In batch mode, it will log the batch with the batch id.
    In loop mode, it will log the 

    Args:
        BaseCallback (_type_): _description_
    """
    def __init__(self,trainer:IBaseTrainer,outdir:str,loss:str=None,method:str = 'min'):
        super().__init__(trainer)
        assert os.path.exists(outdir)
        if method not in COMPARE_METHOD:
            raise ValueError(f"Method should be {list(COMPARE_METHOD.keys())}")
        self.best = COMPARE_METHOD[method]
        self.outdir = outdir
        # Traces are usefull when you want to debug your callback. It keep a trace of the last call
        self.traces = None
        self._modelpath = None
        self._bestLossvalue = None
        self.loss = loss

    def __call__(self,event:TRAINER_EVENTS,**kwargs):
        assert event in self.output_contexts
        for context in self.output_contexts[event]:
            # We iterate over Contexts attached to this event.
            with OutputContext(context):
                self.traces = {str(event):{}}
                if self.loss is None:
                    # We keep the model everytime...
                    self.savemodel()
                    self.traces[event]=self._modelpath
                else:
                    outputs = ICollectable.list()
                    losses = [loss for loss in outputs if loss.name==self.loss]
                    if len(losses)==0:
                        raise KeyError(f"Loss {self.loss} not in outputs")
                    elif len(losses)>1:
                        raise KeyError(f"Multiple Losses {self.loss} with the same name")
                    else:
                        loss = losses[0]
                    loss_value = float(loss.agg())
                    if self._bestLossvalue is None:
                        # We save for the first time...
                        self.savemodel(loss_value=loss_value)
                    else:
                        if loss_value == self.best(loss_value,self._bestLossvalue):
                            os.remove(self._modelpath) # We remove old model
                            self.savemodel(loss_value=loss_value) # We keep best model...

    def savemodel(self,loss_value:float=None):
        """Save a model to the path...

        Args:
            model (IBaseModel): _description_
            path (str): _description_
        """
        if loss_value is None:
            model_name = f"model_epoch_{self.trainer.current_epoch_id}.pth"
        else:
            model_name = f"model_epoch_{self.trainer.current_epoch_id}_loss_{round(loss_value,4)}.pth"
        self._modelpath = os.path.join(self.outdir,model_name)
        self._bestLossvalue = loss_value
        torch.save(self.trainer.model.state_dict(), self._modelpath)
