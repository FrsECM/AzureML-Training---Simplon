from ..factory import IBaseCallback,IBaseTrainer,TRAINER_EVENTS

class BaseCallback(IBaseCallback):
    def __init__(self,trainer:IBaseTrainer):
        assert isinstance(trainer,IBaseTrainer),"trainer should inherit BaseTrainer"
        # Initialize your Callback
        # Exemple : create tensorboard Logger, compute new metrics
        self.trainer=trainer
        self.output_contexts={}

    def attach_event(self,event:TRAINER_EVENTS,context:str=None):
        """
        Attach this callback to a trainer event
        Args:
            event (TRAINER_EVENTS): _description_
            context (str, optional): _description_. Defaults to None.

        """
        if not isinstance(event,TRAINER_EVENTS):
            raise ValueError(f"{event} not in trainer events {list(self.trainer.events.keys())}")
        else:
            if event not in self.trainer.events:
                # We attach the event to the trainer...
                self.trainer.events[event]=[self]
            else:
                if self not in self.trainer.events[event]:
                    self.trainer.events[event].append(self)
                    
            if event not in self.output_contexts:
                self.output_contexts[event]=[context]
            else:
                if context not in self.output_contexts[event]:
                    # Only add if the context don't already exist
                    self.output_contexts[event].append(context)


    def __call__(self,event:TRAINER_EVENTS,**kwargs):
        """ 
        Callback Call
        Do something with :
        # trainer.batch_i   => Current batch ID
        # trainer.batch     => Current batch
        # trainer.output    => Output of the last loop (training / validation)
        # trainer.outputs   => Outputs of all loops since beggining (training/validation)
        Args:
            trainer (BaseTrainer): _description_
            eventname (str): _description_

        Returns:
            _type_: _description_
        """
        return NotImplemented