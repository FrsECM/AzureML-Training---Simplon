from ..factory import IBaseFigure,IResetable,FIGURE_TYPE

class BaseFigure(IBaseFigure,IResetable):
    name = None
    figtype = FIGURE_TYPE.EPOCH
    isGettable = False
    isAggregable = False
    isMulti = False

    def __eq__(self,other):
        if isinstance(other,self.__class__):
            if self.name == other.name:
                return True
        return False