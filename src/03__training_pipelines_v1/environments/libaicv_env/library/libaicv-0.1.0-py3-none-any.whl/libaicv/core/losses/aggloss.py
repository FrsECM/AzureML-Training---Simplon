import torch.nn as nn
import torch
from ..base import BaseLoss

class AggLoss(BaseLoss):
    def __init__(self,name:str='TotalLoss',stack_method=torch.mean):
        super().__init__(name,stack_method)
    def forward(self,value):
        self.update(value)
        return value