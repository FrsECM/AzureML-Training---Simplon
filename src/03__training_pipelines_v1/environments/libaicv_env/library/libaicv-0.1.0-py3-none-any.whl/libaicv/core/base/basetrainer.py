from ..factory import ACCELERATOR, IBaseTrainer,IBaseDataset,IBaseModel,IBaseCallback,TRAINER_EVENTS,ICollectable,OutputContext
from tqdm import tqdm
import torch
from typing import Dict,List
from torch.utils.data import DataLoader,SubsetRandomSampler
import torch.nn as nn
from torch.optim import Adam
from torch.optim.lr_scheduler import _LRScheduler,StepLR,MultiStepLR
from torch.cuda.amp.grad_scaler import GradScaler

class BaseTrainer(IBaseTrainer):
    events = None
    model = None
    current_batch = None
    current_epoch_id = None
    current_batch_id = None
    num_worker = 0
    current_dataset = None
    # protected properties
    _isAMP = False
    _scaler = None
    _scheduler = None
    _optimizer = None

    def __init__(self,model:IBaseModel,**kwargs):
        assert isinstance(model,IBaseModel),"Model should inherit from BaseModel"
        self.model:IBaseModel # Only for Autocompletion...
        self.model = model
        self.events = {k:[] for k in TRAINER_EVENTS}
        self.current_epoch_id = 0
        self.current_batch_id = 0

    def set_kwargs(self,kwargs:dict):
        """Set dynamically attributes from a config file.

        Args:
            config (dict): _description_
        """
        for attribute in dir(self):
            if attribute in kwargs:
                setattr(self,attribute,kwargs[attribute])
                print(f'Override {attribute} => {kwargs[attribute]}')

    ##########################################
    # Event/Loss Management
    ##########################################
    def raise_event(self,key,**kwargs):
        if key not in self.events:
            return
        else:
            if isinstance(self.events[key],list):
                [callback(event=key,**kwargs) for callback in self.events[key]]
            else:
                self.events[key](eventname=key,**kwargs)

    def reset(self,context:str="All"):
        """reset all Collectable outputs.
        It will clear values of all Aggregable outputs

        Args:
            context (str, optional): . Defaults to None.

            If context == "All", reset all contexts.
            If context == "None", reset default context
            Else, reset context
        """
        if context=="All":
            ICollectable.reset(all=True)
            return
        else:
            # Other cases:
            if ICollectable.context is None:
                # If we are not in a context...
                with OutputContext(context) as collection:
                    collection.reset()
            else:
                # If we are already inside a context...
                ICollectable.reset()

    def clear(self,context:str=None):
        """Clear all Collectable outputs

        Args:
            context (str, optional): . Defaults to None.

            If context == "All", clear all contexts.
            If context == "None", clear default context
            Else, clear context
        """
        if context=="All":
            ICollectable.reset(all=True)
            return
        if ICollectable.context is None:
            with OutputContext(context=context) as collection:
                collection.clear()
        else:
            # If we are already inside a context...
            ICollectable.clear()

    def check(self):
        # We check that callbacks are really callbacks...
        for key in self.events:
            for callback in self.events[key]:
                if not isinstance(callback,IBaseCallback):
                    raise ValueError("All Callbacks should inherit of BaseCallback class")
        if self._optimizer is None:
            raise ValueError("Optimizer should be define with self.set_optimizer()")

    ##########################################
    # Training Config
    ##########################################
    def set_optimizer(self,override:bool = False):
        if override:
            self._optimizer = Adam(self.model.parameters(),lr=self.Lr0)
        else:
            if self._optimizer is None:
                self._optimizer = Adam(self.model.parameters(),lr=self.Lr0)            

    def set_StepScheduler(self,step_size:int = 5,gamma:float=0.5):
        """We set a step Scheduler on our model during training...

        Args:
            step_size (int, optional): _description_. Defaults to 5.
            gamma (float, optional): _description_. Defaults to 0.5.
        """
        self.set_optimizer() # Necessary in order to define the scheduler
        if self._optimizer is not None:
            self._scheduler = StepLR(self._optimizer,step_size,gamma)
        else:
            raise ValueError('No Optimizer defined')
    
    def set_MultiStepScheduler(self,milestones:List[int],gamma:float=0.5):
        """We set a MultiStep Scheduler on our model during training...

        Args:
            milestones (List[int]): _description_
            gamma (float, optional): _description_. Defaults to 0.5.

        Raises:
            ValueError: _description_
        """
        self.set_optimizer() # Necessary in order to define the scheduler
        if self._optimizer is not None:
            self._scheduler = MultiStepLR(self._optimizer,milestones,gamma)
        else:
            raise ValueError('No Optimizer defined')

    def scheduler_step(self):
        if self._scheduler:
            self._scheduler:_LRScheduler
            self._scheduler.step()

    ##########################################
    # Training Runtime
    ##########################################
    def getLr(self):
        """Get current Learning Rate Value...

        Raises:
            ValueError: _description_

        Returns:
            _type_: _description_
        """
        if self._optimizer is not None:
            for param_group in self._optimizer.param_groups:
                return param_group['lr']
        else:
            raise ValueError('Optimizer should be set before getting Learning Rate')

    def backward_step(self,loss:nn.Module):
        """Perform loss backpropagation and optimizer step.
        => Manage the scaler for AMP

        Args:
            loss (nn.Module): _description_
        """
        if not self._isAMP:
            # Without AMP
            loss.backward() # We backpropagate the loss..
            self._optimizer.step()
        else:
            # With AMP
            self._scaler.scale(loss).backward() # We backpropagate the loss..
            self._scaler.unscale_(self._optimizer)
            self._scaler.step(self._optimizer)
            self._scaler.update()

    def train_loop(self,dataset:IBaseDataset,batch_size,device:torch.device=torch.device('cpu')):
        # We switch everybody to train
        dataset.train()
        self.model.train()
        # We reset outputs states... 
        # By Default, we reset all contexts   
        self.reset()
        loader=dataset.get_dataloader(name='train',batch_size=batch_size,num_workers=self.num_worker)
        self.raise_event(TRAINER_EVENTS.ON_TRAIN_LOOP_START)
        pbar = tqdm(enumerate(loader),total=len(loader))
        self.model = self.model.to(device)
        # Loop
        for idx,self.current_batch in pbar:
            self.current_batch_id = idx+self.current_epoch_id*len(loader)
            self.raise_event(TRAINER_EVENTS.ON_TRAIN_BATCH_START)
            outputs=self.train_step(self.current_batch,device)
            pbar.set_postfix(**outputs)
            self.raise_event(TRAINER_EVENTS.ON_TRAIN_BATCH_END)
        self.raise_event(TRAINER_EVENTS.ON_TRAIN_LOOP_END)
        self.scheduler_step()
        return

    def val_loop(self,dataset:IBaseDataset,batch_size,device:torch.device=torch.device('cpu')):
        # We switch everybody to eval
        dataset.eval()
        self.model.eval()
        # We reset outputs states...
        # By Default, we reset all contexts
        self.reset()
        loader=dataset.get_dataloader(name='val',batch_size=batch_size,num_workers=self.num_worker)
        self.raise_event(TRAINER_EVENTS.ON_VAL_LOOP_START)
        pbar = tqdm(enumerate(loader),total=len(loader))
        self.model = self.model.to(device)
        # Loop
        for idx,self.current_batch in pbar:
            self.current_batch_id = idx+self.current_epoch_id*len(loader)
            self.raise_event(TRAINER_EVENTS.ON_VAL_BATCH_START)
            outputs=self.val_step(self.current_batch,device)
            pbar.set_postfix(**outputs)
            self.raise_event(TRAINER_EVENTS.ON_VAL_BATCH_END)
        self.raise_event(TRAINER_EVENTS.ON_VAL_LOOP_END)
        return
    
    def fit(self,dataset:IBaseDataset,batch_size:int=4,epochs:int=10,accelerator:ACCELERATOR=ACCELERATOR.CPU,**kwargs):
        assert isinstance(dataset,IBaseDataset),"Dataset should inherit from BaseDataset"
        # We put the dataset as an accessible property.
        self.current_dataset = dataset
        if accelerator == ACCELERATOR.CPU:
            print(f'[INFO] Device = CPU...')
            device = torch.device('cpu')
        elif accelerator ==ACCELERATOR.CUDA:
            if torch.cuda.is_available():
                print(f'[INFO] CUDA is Available => Device = CUDA...')
                device = torch.device('cuda')
            else:
                print(f'[WARNING] CUDA is not Available => Back to CPU...')
                device = torch.device('cpu')
        elif accelerator ==ACCELERATOR.CUDA_AMP:
            if torch.cuda.is_available():
                print(f'[INFO] CUDA is Available => Device = CUDA + AMP...')
                device = torch.device('cuda')
                # We set the model in AMP...
                self._isAMP = True
                self._scaler = GradScaler()
            else:
                print(f'[WARNING] CUDA is not Available => Back to CPU...')
                device = torch.device('cpu')
        else:
            raise ValueError(f'Accelerator {accelerator}, not implemented')
        self.set_kwargs(kwargs)
        # We set optimizer if it is not alread set...
        self.set_optimizer()
        self.check()
        for self.current_epoch_id in range(epochs):
            print(f"Epochs {self.current_epoch_id+1}/{epochs}")
            self.raise_event(TRAINER_EVENTS.ON_EPOCH_LOOP_START)
            dataset.train()
            self.raise_event(TRAINER_EVENTS.BEFORE_TRAIN_LOOP)
            self.train_loop(dataset,batch_size,device)
            self.raise_event(TRAINER_EVENTS.AFTER_TRAIN_LOOP)
            dataset.eval()
            self.raise_event(TRAINER_EVENTS.BEFORE_VAL_LOOP)
            self.val_loop(dataset,batch_size,device)
            self.raise_event(TRAINER_EVENTS.AFTER_VAL_LOOP)
            self.raise_event(TRAINER_EVENTS.ON_EPOCH_END)

