import torch
import torch.nn as nn
from ..base import BaseLoss

class CrossEntropyLoss(BaseLoss):
    def __init__(self, name:str='CELoss',weights=None,reduction='mean'):
        super().__init__(name,stack_method=torch.mean) # Focal Loss is stacked by mean
        self.weights=weights
        self.criterion = nn.CrossEntropyLoss(weights,reduction=reduction)
    def forward(self,input,target):
        _loss = self.criterion(input,target)
        self.update(_loss)
        return _loss
