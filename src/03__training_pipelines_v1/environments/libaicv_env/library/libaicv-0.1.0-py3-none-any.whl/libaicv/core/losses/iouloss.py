import torch.nn as nn
import torch
import torch.nn.functional as F
from ..base import BaseLoss


class IoULoss(BaseLoss):
    def __init__(self,name:str="IoULoss",reduction='mean'):
        super().__init__(name,stack_method=torch.mean)
        self._epsilon=1e-15
        self._reduction=reduction

    def forward(self, pred, target):
        assert len(pred.shape)>=3,"prediction shape should be at least len 3"
        assert pred.shape[0]==target.shape[0],"prediction, and target should have the same batch size"
        assert target.dtype in [torch.long],"target should be a long."
        assert len(pred.shape)==len(target.shape)+1,"target and prediction should be [B,*], and [B,C,*]"
        # On récupère les indices positifs et négatifs...
        batchSize=pred.shape[0]
        nClasses=pred.shape[1]
        pred_soft=torch.softmax(pred,dim=1).view(batchSize,nClasses,-1)
        target_one_hot=F.one_hot(target.view(batchSize,-1),num_classes=nClasses).permute(0,2,1).float()
        inter=pred_soft*target_one_hot
        union= pred_soft + target_one_hot - (pred_soft*target_one_hot)
        IoU=(inter.sum(-1)+1)/(union.sum(-1)+1)
        _loss=1-IoU
        if self._reduction:
            if self._reduction=='sum':
                _loss = _loss.sum()
            else:
                _loss = _loss.mean()
        self.update(_loss) # On ajoute la loss à la sortie...
        return _loss