from ..factory import IBaseFigure, IBaseFrequential,FIGURE_TYPE

class BaseFrequential(IBaseFrequential,IBaseFigure):
    name = None
    figtype = FIGURE_TYPE.BATCH
    isMulti = False
    isGettable = False
    isAggregable = False
    def __init__(self,name:str,freq:int=100):
        self.name = name
        self.freq = freq
    def isActive(self,batch_idx):
        return batch_idx%self.freq==0

    def __eq__(self,other):
        if isinstance(other,self.__class__):
            if self.name == other.name:
                if self.freq == other.freq:
                    return True
        return False