import torch
import enum
import numpy as np
import matplotlib.pyplot as plt
from typing import List
import matplotlib
from ..base import BaseFigure
from ..factory import IBaseFigure

def getVerdicts(prediction:torch.Tensor,target:torch.Tensor,threshold:float):
    """ prediction and target should be the same shape

    Args:
        prediction (torch.Tensor): [B,*] matrix
        target (torch.Tensor): [B,*] matrix
    """
    if prediction.shape!=target.shape:
        raise ValueError(
            f"""
            prediction {prediction.shape[0]} and target {target.shape[0]} batchsize
            should be equals
            """
        )
    tp = torch.logical_and(prediction>=threshold,target==1).sum().detach().cpu()
    tn = torch.logical_and(prediction<threshold,target!=1).sum().detach().cpu()
    fp = torch.logical_and(prediction>=threshold,target!=1).sum().detach().cpu()
    fn = torch.logical_and(prediction<threshold,target==1).sum().detach().cpu()
    return tp,tn,fp,fn

def PlotViDiCurve(TP,TN,FP,FN,Thresholds,Label):
    """Returns a ViDi like figure to plot in tensorboard
    Args:
        Verdicts (torch.Tensor): [nThresholds,4] => TP,TN,FP,FN
        Thresholds ([type]): [nThresholds]
    Returns:
        [fig]: [description]
    """
    fig,ax=plt.subplots(1,1,figsize=(10,8))
    plt.rc('font', size=10)
    distC=FP/(TN+FP+1e-5) # FP/(TN+FP)
    distNC=FN/(TP+FN+1e-5) # FN/(TP+FN)
    ax.plot(Thresholds,distC,color='g',label='OK')
    ax.fill_between(Thresholds,distC,color='g',alpha=0.5)
    ax.plot(Thresholds,distNC,color='r',label='NOK')
    ax.fill_between(Thresholds,distNC,color='r',alpha=0.5)
    ax.set_xlabel('Thresholds')
    ax.set_ylabel(f'Distribution {Label}')
    ax.legend()
    return fig

def PlotPRCurve(TP,TN,FP,FN,Thresholds,Label):
    """Returns a PRCurve figure to plot in tensorboard
    Args:
        Verdicts (torch.Tensor): [nThresholds,4] => TP,TN,FP,FN
        Thresholds ([type]): [nThresholds]
    Returns:
        [fig]: [description]
    """
    Recalls=TP/(TP+FN+1e-5)
    Precisions=TP/(TP+FP+1e-5)
    # We plot the curve
    Colors=['r','g']
    fig,ax=plt.subplots(1,1,figsize=(6,6),dpi=155)
    plt.rc('font', size=10)
    data=[Precisions,Recalls]
    for m,mtype in enumerate(['precision','recall']):
        color=Colors[m]
        lb=f"{mtype}_{Label}"
        ax.plot(Thresholds,
            data[m],label=lb,
            color=color,linestyle='-',linewidth=4)
    minor_ticks=np.arange(0,1.01,0.05)
    major_ticks=np.arange(0,1.01,0.1)
    ax.set_xticks(minor_ticks,minor=True)
    ax.set_yticks(minor_ticks,minor=True)
    ax.set_xticks(major_ticks)
    ax.set_yticks(major_ticks)
    ax.grid(which='major',color='#DDDDDD',linestyle='-')
    ax.grid(which='minor',color='#EEEEEE',linestyle='--')
    ax.set_xlabel('threshold')
    ax.set_ylabel(f"{Label} value")
    ax.legend()
    return fig


class VFMODE(enum.Enum):
    PRCURVE     = 0
    VIDICURVE   = 1

class VerdictFigure(BaseFigure):
    isMulti = True # Returns a List[Tuple[str,fig]]
    def __init__(self,name,clsIDs:List[int],clsNames:List[str],modes:List[VFMODE],n_thresholds:int=25):
        self.name = name
        """Create a Verdict Figure based on thresholds...

        Args:
            n_thresholds (int, optional): _description_. Defaults to 25.
        """
        if not isinstance(clsIDs,(list,range)):
            raise TypeError('cls_ids should be a list')
        if not isinstance(modes,list):
            raise TypeError('modes should be a list')
        assert max(clsIDs)<=len(clsNames),"ClassNames should contain at least maxId items..."
        # We create properties
        self.thresholds = torch.linspace(0,1,n_thresholds)
        self.cls_ids = clsIDs
        self.clsNames = clsNames
        self.modes = modes
        # We create accumulators...
        self.reset()
        matplotlib.use('agg')

    def reset(self):
        # We add 4 accumulators by thresholds...
        for t in self.thresholds:
            for cls_id in self.cls_ids:
                setattr(self,f"true_positive_t{t}_c{cls_id}",torch.tensor(0))
                setattr(self,f"false_positive_t{t}_c{cls_id}",torch.tensor(0))
                setattr(self,f"true_negative_t{t}_c{cls_id}",torch.tensor(0))
                setattr(self,f"false_negative_t{t}_c{cls_id}",torch.tensor(0))

    def __call__(self,y_hat:torch.Tensor,y:torch.Tensor,apply_softmax:bool = True):
        """We call the figure verdict

        Args:
            y_hat (torch.Tensor): _description_
            y (torch.Tensor): _description_
            apply_softmax (bool, optional): _description_. Defaults to True.

        Returns:
            _type_: _description_
        """
        return self.update(y_hat,y,apply_softmax)

    def update(self,y_hat:torch.Tensor,y:torch.Tensor,apply_softmax:bool = True):
        if apply_softmax:
            y_hat_softmax = y_hat.softmax(dim=1)
        else:
            y_hat_softmax = y_hat

        for t in self.thresholds:
            for cls_id in self.cls_ids:
                # We get corresponding states attributes
                TP_attr = getattr(self,f'true_positive_t{t}_c{cls_id}')
                TN_attr = getattr(self,f'true_negative_t{t}_c{cls_id}')
                FP_attr = getattr(self,f'false_positive_t{t}_c{cls_id}')
                FN_attr = getattr(self,f'false_negative_t{t}_c{cls_id}')
                # We get values and add to states
                tp,tn,fp,fn = getVerdicts(y_hat_softmax[:,cls_id],y == cls_id,threshold=t)
                TP_attr += tp
                TN_attr += tn
                FP_attr += fp
                FN_attr += fn

    def generate(self):
        result = []
        for mode in self.modes:
            for cls_id in self.cls_ids:
                label = self.clsNames[cls_id]
                mode_str = 'PRCURVE' if mode == VFMODE.PRCURVE else 'ViDiCURVE'
                fig = self.__generate(mode,label,cls_id)
                result.append((f"{mode_str}_{label}",fig))
        return result
                
    def __generate(self,mode:VFMODE=VFMODE.PRCURVE,label='',cls_id:int=1):
        """Compute the PRCurve or ViDiCurve
        Args:
            mode (VFMODE, optional): _description_. Defaults to VFMODE.PRCURVE.
            label (str, optional): _description_. Defaults to ''.

        Returns:
            _type_: _description_
        """
        if cls_id not in self.cls_ids:
            raise ValueError(f'cls_id {cls_id} should be in self.cls_ids {self.cls_ids}')
        TP = torch.tensor([getattr(self,f'true_positive_t{t}_c{cls_id}') for t in self.thresholds])
        TN = torch.tensor([getattr(self,f'true_negative_t{t}_c{cls_id}') for t in self.thresholds])
        FP = torch.tensor([getattr(self,f'false_positive_t{t}_c{cls_id}') for t in self.thresholds])
        FN = torch.tensor([getattr(self,f'false_negative_t{t}_c{cls_id}') for t in self.thresholds])
        if mode == VFMODE.PRCURVE:
            return PlotPRCurve(TP,TN,FP,FN,self.thresholds,Label=label)
        else:
            return PlotViDiCurve(TP,TN,FP,FN,self.thresholds,Label=label)