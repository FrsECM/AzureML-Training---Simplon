from abc import ABC, ABCMeta,abstractclassmethod, abstractmethod
from torch.utils.data import Dataset,DataLoader
import torch.nn as nn
import torch
import numpy as np
import enum
from typing import Dict,Tuple,List,Union
import matplotlib.pyplot as plt

@enum.unique
class TRAINER_EVENTS(enum.Enum):
    ON_EPOCH_LOOP_START     = 0
    BEFORE_TRAIN_LOOP       = 1
    ON_TRAIN_LOOP_START     = 2
    ON_TRAIN_BATCH_START    = 3
    ON_TRAIN_BATCH_END      = 4
    ON_TRAIN_LOOP_END       = 5
    AFTER_TRAIN_LOOP        = 6
    BEFORE_VAL_LOOP         = 7
    ON_VAL_LOOP_START       = 8
    ON_VAL_BATCH_START      = 9
    ON_VAL_BATCH_END        = 10
    ON_VAL_LOOP_END         = 11
    AFTER_VAL_LOOP          = 12
    ON_EPOCH_END            = 13
    
    def aggregate(event)->bool:
        return not 'BATCH' in str(event)
    def phase(event)->str:
        return str(event.name).split('_')[1]

@enum.unique
class ACCELERATOR(enum.Enum):
    CPU        = 0
    CUDA       = 1
    CUDA_AMP   = 2

@enum.unique
class OUTPUT_TYPE(enum.Enum):
    SCALAR = 0
    FIGURE = 1

class FIGURE_TYPE(enum.Enum):
    BATCH = 0
    EPOCH = 1

class PPROCESS(enum.Enum):
    STANDARDIZE = 0
    NORMALIZE   = 1

class IBaseFrequential(ABC):
    @abstractmethod
    def isActive(self)->bool:pass

class OutputContextIterator():
    def __init__(self,output_collection:'OutputContext'):
        # Team object reference
        self._context = output_collection
        # member variable to keep track of current index
        self._index = 0
    def __next__(self):
        if self._index < len(self._context.list()):
            result = self._context.list()[self._index]
            self._index +=1
            return result
        # End of Iteration
        raise StopIteration

class OutputContext:
    # Instance Methods
    context = None
    _inside_context = False
    def __init__(self,context=None):
        # Each time we'll create an instance of ICollection, we reset it.
        self.context = context
        if ICollectable.context is not None:
            raise RuntimeError("Context can't be used inside context")
        ICollectable.context=self.context
    
    def raise_if_outside_context(method):
        def decorator(self,*args,**kwargs):
            if not self._inside_context:
                raise RuntimeError(f"{self.__class__} must be use as a context")
            return method(self,*args,**kwargs)
        return decorator
    
    @raise_if_outside_context
    def list(self):
        # We list in current context
        return ICollectable.list()

    @raise_if_outside_context
    def get(self,output_name)->'IBaseOutput':
        # We list in current context
        return ICollectable.get(output_name)

    @raise_if_outside_context
    def __getitem__(self,output_name)->'IBaseOutput':
        # We list in current context
        return self.get(output_name)

    @raise_if_outside_context
    def clear(self):
        """Clear every instance of ICollectable"""
        # We clear in current context
        return ICollectable.clear()

    @raise_if_outside_context
    def reset(self):
        # We reset in current context
        return ICollectable.reset()  

    @raise_if_outside_context
    def __contains__(self, output_name:str):
        # We check in current context
        return output_name in [output.name for output in ICollectable.list()]     

    @raise_if_outside_context
    def __iter__(self)->'IBaseOutput':
        return OutputContextIterator(self)

    def __enter__(self)->'OutputContext':
        self._inside_context = True
        return self
    def __exit__(self, type, value, traceback):
        # We reset context
        ICollectable.context=None

class ICollectable(ABCMeta):
    """ICollectable is a Singleton.
    The idea is that an output with exactly the same parameters should be only one instance.

    """
    __outputs = {None:{}}
    context = None
    def __call__(cls,name,*args, **kwargs):
        # We create a unique key for the new class instancied
        # We use the context in order to have unique instance per contexts
        # By default, the context is None
        if cls.context not in cls.__outputs:
            cls.__outputs[cls.context] = {}
        output_instances = cls.__outputs[cls.context]
        # BugFix 20/12/2022 => Contextual Singleton equality not working with frequential
        if "freq" in kwargs:
            # We are in the case of a Frequential
            key = name+str(kwargs['freq'])
        else:
            # We create or get the instance of the singleton
            key = name #(cls.__name__,name)
        if key not in output_instances:
            # If not existing, we create a new instance...
            output_instances[key] = super(ICollectable, cls).__call__(name=name,*args, **kwargs)
        if output_instances[key].__class__.__name__!=cls.__name__:
            raise ValueError("An instance already exist with this name and another Class")
            # Else, we return the existing instance.
        return output_instances[key]
    def list(all:bool=False)->List['IBaseOutput']:
        """Returns all Outputs...

        Returns:
            _type_: _description_
        """
        if all:
            # If all, we return all contexts
            result = []
            for context in ICollectable.__outputs:
                result.extend(ICollectable.__outputs[context].values())
            return result
        if ICollectable.context in ICollectable.__outputs:
            return list(ICollectable.__outputs[ICollectable.context].values())
        else:
            return []
    def clear(all:bool=False):
        """
        Clear all ICollectable Instance
        We :
        - Remove Instances
        """
        if all:
            del ICollectable.__outputs
            ICollectable.__outputs={}
        if ICollectable.context in ICollectable.__outputs:
            del ICollectable.__outputs[ICollectable.context]
    def reset(all:bool=False):
        """
        Reset all ICollectable instance
        We :
        - Reset outputs values
        """
        for output in ICollectable.list(all):
            if isinstance(output,(IResetable)):
                output.reset()
    def get(output_name)->'IBaseOutput':
        """Returns the loss with the name

        Args:
            name (_type_): _description_

        Returns:
            _type_: _description_
        """
        losses = [loss for loss in ICollectable.list() if loss.name == output_name]            
        if len(losses) ==1:
            return losses[0]
        else:
            raise KeyError('{loss_name} not in Collection or Context')

class IBaseOutput(metaclass=ICollectable): #metaclass=ICollectable):
    # Properties
    @property
    @abstractmethod
    def name(self)->str:pass
    @abstractclassmethod
    def __eq__(self,other)->bool:pass

class IResetable(ABC):
    @abstractclassmethod
    def reset(self):pass

class IBaseScalar(IBaseOutput,IResetable):
    @property
    @abstractmethod
    def isAggregable(self)->bool:pass
    @property
    @abstractmethod
    def isGettable(self)->bool:pass

    @abstractclassmethod
    def update(self):pass
    @abstractclassmethod
    def get(self):pass
    @abstractclassmethod
    def agg(self):pass

class IBaseFigure(IBaseOutput):
    @property
    @abstractmethod
    def isMulti(self)->str:pass
    @property
    @abstractmethod
    def figtype(self)->FIGURE_TYPE:pass

    @abstractmethod
    def update(self):pass
    
    @abstractmethod
    def generate(self)->plt.Figure:pass

class IBaseInput(ABC):
    @property
    @abstractmethod
    def name(self)->str:pass
    @abstractclassmethod
    def get_data(self)->np.ndarray:pass
    @abstractclassmethod
    def get_target(self)->np.ndarray:pass

class IBaseModel(ABC,nn.Module):
    @property
    @abstractmethod
    def name(self)->str:pass

    @abstractmethod
    def save_dict(self,modelpath):pass
    @abstractmethod
    def save_jit(self,modelpath,input):pass

    @abstractmethod
    def forward(self,x):pass

class IBaseTrainer(ABC):
    @property
    @abstractmethod
    def events(self)->Dict[str,TRAINER_EVENTS]:pass
    @property
    @abstractmethod
    def current_epoch_id(self)->int:pass
    @property
    @abstractmethod
    def current_batch_id(self)->int:pass
    @property
    @abstractmethod
    def current_batch(self):pass
    @property
    @abstractmethod
    def current_dataset(self)->'IBaseDataset':pass
    @property
    @abstractmethod
    def num_worker(self)->int:pass
    @property
    @abstractmethod
    def model(self):pass

    ### Trainer Config
    @abstractmethod
    def set_optimizer(self):pass

    ### Event/Loss Management
    @abstractmethod
    def raise_event(self):pass
    @abstractmethod
    def reset(self,context:str='All'):pass
    @abstractmethod
    def clear(self,context:str='All'):pass

    ### Trainer Runtime
    @abstractmethod
    def check(self)-> bool:pass
    @abstractmethod
    def getLr(self)-> bool:pass
    @abstractmethod
    def backward_step(self)-> bool:pass
    
    @abstractmethod
    def train_loop(self,**kwargs):pass
    @abstractmethod
    def val_loop(self,**kwargs):pass
    @abstractmethod
    def fit(self,**kwargs):pass


    @abstractmethod
    def train_step(self,**kwargs)->Dict[str,IBaseOutput]:pass
    @abstractmethod
    def val_step(self,**kwargs)->Dict[str,IBaseOutput]:pass
    @abstractmethod
    def test_step(self,**kwargs)->Dict[str,IBaseOutput]:pass


class IBaseDataset(ABC,Dataset):
    @property
    @abstractmethod
    def train_indices(self)->list:pass
    @property
    @abstractmethod
    def val_indices(self)->list:pass
    @property
    @abstractmethod
    def test_indices(self)->list:pass
    @property
    @abstractmethod
    def data(self)->list:pass
    @property
    @abstractmethod
    def istraining(self)->bool:pass
    @property
    @abstractmethod
    def pprocess(self)->PPROCESS:pass
    
    @abstractclassmethod
    def get_indices(self)->Tuple[List[int],List[int],List[int]]:pass  
    @abstractclassmethod
    def get_dataloader(self,name:str,batch_size:int,num_workers:int)->DataLoader:pass
    @abstractclassmethod
    def train(self,train:bool=True):pass
    @abstractclassmethod
    def eval(self,eval:bool=True):pass
    @abstractclassmethod
    def __len__(self):pass
    @abstractclassmethod
    def split(self,train_ratio:float = 0.8,val_ratio:float = 0.1,test_ratio:float = 0.1 ,seed=42):pass
    @abstractclassmethod
    def __getitem__(self,idx):pass

class IBaseCallback(ABC):
    @abstractclassmethod
    def __init__(self,trainer:IBaseTrainer):pass
    @abstractclassmethod
    def __call__(self,event:TRAINER_EVENTS,**kwargs):pass
    @abstractclassmethod
    def attach_event(self,event:TRAINER_EVENTS,context:str = None):pass