from ..factory import IBaseOutput,OUTPUT_TYPE, IBaseScalar
import torch.nn as nn
import torch

class BaseLoss(IBaseScalar,nn.Module):
    name = None
    isAggregable = True
    isGettable = True
    def __init__(self,name:str,stack_method):
        # We call constructors
        self.name = name
        nn.Module.__init__(self)
        # The type is scalar by default for losses...
        self._stack_method = stack_method
        self._items = []
    def __eq__(self,other):
        if isinstance(other,self.__class__):
            if self.name == other.name:
                return True
        return False  
    def reset(self):
        self._items=[]
    def update(self,value):
        self._items.append(value)
    def get(self):
        if len(self._items)>0:
            return self._items[-1]
        else:
            return 0
    def agg(self):
        if len(self._items)>0:
            return self._stack_method(torch.tensor(self._items,dtype=torch.float))
        else:
            return 0