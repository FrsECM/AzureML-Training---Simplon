from . import BaseCallback
from ..factory import FIGURE_TYPE, IBaseFigure, IBaseFrequential, IBaseModel, IBaseOutput, IBaseScalar, IBaseTrainer,TRAINER_EVENTS, ICollectable, OutputContext
from torch.utils.tensorboard.writer import SummaryWriter
from datetime import datetime
import os


class TensorboardCallback(BaseCallback):
    """
    The aim of this callback is to log metrics in tensorboard.
    There is two modes :
    - Batchs
    - Loops
    In batch mode, it will log the batch with the batch id.
    In loop mode, it will log the 

    Args:
        BaseCallback (_type_): _description_
    """
    def __init__(self,trainer:IBaseTrainer,rootLogDir='tb_results',LogDir_suffix='',log_LR:bool=True):
        super().__init__(trainer)
        logdir=os.path.join(rootLogDir,datetime.now().strftime("%y%m%d_%H%M")+f"_{LogDir_suffix}")
        os.makedirs(logdir,exist_ok=True)
        self.logdir=logdir
        self.logwriter=SummaryWriter(logdir)
        self.output_contexts={}
        # Traces are usefull when you want to debug your callback. It keep a trace of the last call
        self.traces = None
        if log_LR:
            # We attach the ON_TRAIN_LOOP_START EVENT to log Lr
            # We set context == LearningRate to avoid double log of Training Losses
            self.attach_event(TRAINER_EVENTS.ON_TRAIN_LOOP_START,"LearningRate") 

    def __log_scalar(self,event,scalar_instance:IBaseScalar):
        if TRAINER_EVENTS.aggregate(event):
            if scalar_instance.isAggregable:
                index = self.trainer.current_epoch_id
                suffix = "EPOCH"
                value = scalar_instance.agg()
            else:
                return # We pass to the next item...
        else:
            if scalar_instance.isGettable:
                index = self.trainer.current_batch_id
                suffix = "BATCH"
                value = scalar_instance.get()
            else:
                return # We pass to the next item...
        key = f"{TRAINER_EVENTS.phase(event)}{suffix}/{scalar_instance.name}"
        self.logwriter.add_scalar(key,value,global_step=index)
        self.traces[str(event)].update({scalar_instance.name:(index,float(value))})

    def __log_figure(self,event,figure_instance:IBaseFigure):
        if TRAINER_EVENTS.aggregate(event):
            if figure_instance.figtype == FIGURE_TYPE.EPOCH:
                index = self.trainer.current_epoch_id
            else:
                return 
        else:
            if figure_instance.figtype == FIGURE_TYPE.BATCH:
                index = self.trainer.current_batch_id
            else:
                return
        if figure_instance.isMulti:
            for (name,fig) in figure_instance.generate():
                key = f"{TRAINER_EVENTS.phase(event)}{figure_instance.figtype.name}/{name}"
                self.logwriter.add_figure(key,fig,global_step=index)
                self.traces[str(event)].update({name:(index,'figure')})
        else:
            key = f"{TRAINER_EVENTS.phase(event)}{figure_instance.figtype.name}/{figure_instance.name}"
            value = figure_instance.generate()
            self.logwriter.add_figure(key,value,global_step=index)
            self.traces[str(event)].update({figure_instance.name:(index,'figure')})
        return
    
    def __call__(self,event:TRAINER_EVENTS,**kwargs):
        assert event in self.output_contexts
        with OutputContext(context=self.output_contexts[event]):
            self.traces = {str(event):{}}
            # Phase is everytime the second term of event name
            # If batch is in event name, it means we'll use output, else : outputs
            # We get outputs...
            assert isinstance(self.trainer.model,IBaseModel)
            outputs=ICollectable.list() # We get all collectable outputs...

            ################################################################################
            # Lr - Logging
            ################################################################################
            if event == TRAINER_EVENTS.ON_TRAIN_LOOP_START:
                # We log the learning Rate
                # We will log it every TRAIN LOOP START
                Lr_value = self.trainer.model.getLr()
                self.logwriter.add_scalar("TRAINEPOCH/LearningRate",Lr_value,global_step=self.trainer.current_epoch_id)
                self.traces[str(event)].update({'TRAINEPOCH/LearningRate':Lr_value})

            ################################################################################
            # Outputs - Logging
            ################################################################################
            for output_instance in outputs:
                output_instance:IBaseOutput
                if isinstance(output_instance,IBaseFrequential):
                    # In case we have a frequential :
                    # we'check that it is currently active...
                    if not output_instance.isActive(self.trainer.current_batch_id):
                        continue # We dont compute.
                if isinstance(output_instance,IBaseScalar):
                    # We process it as a BaseOutput
                    self.__log_scalar(event,output_instance)
                    continue
                if isinstance(output_instance,IBaseFigure):
                    self.__log_figure(event,output_instance)
            
