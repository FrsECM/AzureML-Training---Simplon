from .l2loss import L2Loss
from .focalcrossentropyloss import FocalCrossEntropyLoss
from .iouloss import IoULoss
from .aggloss import AggLoss
from .crossentropyloss import CrossEntropyLoss
