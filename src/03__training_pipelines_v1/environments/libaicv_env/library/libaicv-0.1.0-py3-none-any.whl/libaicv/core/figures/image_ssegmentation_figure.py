from ..factory import PPROCESS
from ...utils.image import colorize_segmentation,transform,reverse
from ..base.basefrequential import BaseFrequential
from ..factory import IBaseFigure

import matplotlib.pyplot as plt
import numpy as np
from torch import nn
import torch
import matplotlib


def plot_SemanticSegmentationImages(X:torch.Tensor,y:torch.Tensor,y_pred:torch.Tensor,norm:PPROCESS=PPROCESS.STANDARDIZE,display_dim:int=0):
    """Plot image matrix
    Args:
        X (torch.tensor): Tensor [B,3,H,W] or [B,H,W]  containing Original Images [C = 3 or C ==1]
        y (torch.tensor): Tensor [B,H,W] containing prediction as a class matrix
        y_hat (torch.tensor): Tensor [B,H,W] containing target as a class matrix
    Returns:
        figure : Matplotlib figure
    """
    # We check that image is in the correct format...
    if len(X.shape) not in [4,3]:
        raise ValueError('Tensor should be [B,N,H,W],[B,3,H,W],[B,1,H,W] or [B,H,W]')
    if len(X.shape)==3:
        # We unsqueeze dim 1 to be able to go through reverse process..
        X=X.unsqueeze(1)
    else:
        if X.shape[1] not in [1,3]:
            X = X[:,display_dim,:,:].unsqueeze(1)
    # We check that target is in correct format
    assert X.shape[1] in [1,3],"Image should have 1 or 3 channels"
    image = reverse(X,norm).squeeze()
    nBatch=X.shape[0]
    Y_flat_numpy=y.detach().cpu().numpy()
    Y_pred_numpy=y_pred.detach().cpu().numpy()
    fig,ax=plt.subplots(3,nBatch,figsize=(16,9))
    # We plots :
    # - Original Image
    # - Target
    # - Prediction
    for i in range(nBatch):
        if nBatch==1:
            ax[0].imshow(image[i],cmap='gray', vmin = 0, vmax = 255)
            ax[1].imshow(colorize_segmentation(Y_flat_numpy[i,:,:]))
            ax[2].imshow(colorize_segmentation(Y_pred_numpy[i,:,:]))
        else:
            ax[0,i].imshow(image[i],cmap='gray', vmin = 0, vmax = 255)
            ax[1,i].imshow(colorize_segmentation(Y_flat_numpy[i,:,:]))
            ax[2,i].imshow(colorize_segmentation(Y_pred_numpy[i,:,:]))
    plt.axis('off')
    return fig

class ImageSemanticSegmentationFigure(BaseFrequential):
    isMulti = False
    def __init__(self,name:str,freq:int=100,pprocess:PPROCESS=PPROCESS.STANDARDIZE,display_dim:int=0,max_count:int=4):
        """Plot image segmentation prediction and groundtruth.

        Args:
            freq (int, optional): _description_. Defaults to 100.
            pprocess (PPROCESS,optional): Preprocessing applyed in the dataset. Default PPROCESS.STANDARDIZE
            display_dim (int, optional): _description_. Defaults to 0.
        """
        BaseFrequential.__init__(self,name,freq)
        self.X = None
        self.y = None
        self.y_hat = None
        self.apply_softmax = False

        self.pprocess = pprocess
        self.display_dim = display_dim
        self.max_count=max_count
        matplotlib.use('agg')

    def generate(self):
        """Compute the figure
        """
        assert self.X is not None
        assert self.y is not None
        assert self.y_hat is not None
        if self.apply_softmax:
            y_hat_max = self.y_hat.softmax(dim=1).max(dim=1)[1]
        else:
            y_hat_max = self.y_hat.max(dim=1)[1]
        batch_size = self.X.shape[0]
        if self.max_count<batch_size:
            X=self.X[:self.max_count]
            y=self.y[:self.max_count]
            y_hat_max = y_hat_max[:self.max_count]
        else:
            X = self.X
            y = self.y
        fig=plot_SemanticSegmentationImages(X,y,y_hat_max,self.pprocess,display_dim = self.display_dim)
        return fig

    def update(self,X:torch.Tensor,y:torch.Tensor,y_hat:torch.Tensor,apply_softmax:bool = True):
        """_summary_

        Args:
            X (torch.Tensor): Images
            y (torch.Tensor): target
            y_hat (torch.Tensor): prediction as Tensor or Softmax
            apply_softmax (bool, optional): _description_. Defaults to True.
        """
        self.X = X
        self.y = y
        self.y_hat = y_hat
        self.apply_softmax = apply_softmax
    
    def __call__(self,X:torch.Tensor,y:torch.Tensor,y_hat:torch.Tensor,apply_softmax:bool = True):
        self.update(X,y,y_hat,apply_softmax)