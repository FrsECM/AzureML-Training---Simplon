from ..factory import IBaseScalar,OUTPUT_TYPE

class BaseMetric(IBaseScalar):
    name = None
    isAggregable = True
    isGettable = True
    def __init__(self,name:str):
        """
        Args:
            name : Name of the Metric
            type (METRIC_TYPE, optional): _description_. Defaults to METRIC_TYPE.SCALAR.
        """
        self.name = name
    
    def __eq__(self,other):
        if isinstance(other,self.__class__):
            if self.name == other.name:
                return True
        return False
